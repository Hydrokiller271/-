package com.sk.handler;

import com.sk.game.*;
import com.sk.game.utils.*;



import com.sk.game.tiles.*;
import com.sk.game.graphics.*;
import com.sk.game.states.*;

public class Handler {
	
	private GamePanel game;
	private TileManager tm;
	private GameStateManager G;
	//Constructor
	public Handler(GamePanel game) {
		this.game = game	;
	}
	public Handler(GameStateManager g) {
		this.G = g;
	}
	public GameStateManager getGameS() {
		return G;
	}
	
	public void setGameS(GameStateManager g) {
		this.G = g;
	}
	
	//GetGamePanel
	public GamePanel getGame() {
		return game;
	}
	
	//SetGame
	public void setGame(GamePanel game) {
		this.game = game;
	}
	//GetWorld
	public TileManager getMap() {
		return tm;
	}
	//SetWorld
	public void setMap(TileManager tm) {
		this.tm = tm;
	}
	
	//GetWidth
		public int getWidth() {
			return game.getWidth()	;
		}
		//GetHeight
		public int getHeight() {
			return game.getHeight()	;
		}
		
		//GetKeyManager
		public KeyHandler getKey() {
			return game.getKey()	;
		}
		
		//GetGameCamera
	
		
		//GetMouseManager
		public MouseHandler getMouse() {
			return game.getMouse();
		}
	//getRunning
	public boolean getRunning() {
		return game.getRunning();
	}
	//GameStop
	public void gameStop() {
		game.setRunning(false);
		System.exit(0);
		
	}
}
