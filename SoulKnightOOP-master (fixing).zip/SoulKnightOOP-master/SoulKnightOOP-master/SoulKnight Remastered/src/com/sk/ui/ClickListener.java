package com.sk.ui;

public interface ClickListener {
	
	public void onClick();
	public void test();
}
