package com.sk.game.graphics;

import java.awt.image.BufferedImage;

import ImageLoader.ImageLoader;


public class Assets {
private static final int width = 32,height = 32;
	
	public static BufferedImage red,cyan,blue,green, orange,purple,gray,yellow;

	public static BufferedImage[] all,btn_start,btn_end;

	public static BufferedImage[] player_up,player_right,player_left,player_down;

	public static void init() {
			Sprite sheet = new Sprite(ImageLoader.loadImage("tile/desertdoodles.png"));
			
			player_up = new BufferedImage[2];
			player_left =new BufferedImage[2];
			player_right =new BufferedImage[2];
			player_down =new BufferedImage[2];
			all = new BufferedImage[2];
			
			btn_start = new BufferedImage[2];
			btn_end = new BufferedImage[2];
			
			red = sheet.crop(0, 0, width, height);
			cyan = sheet.crop(width,0 , width, height);
			blue = sheet.crop(width*2,0 , width, height);
			green = sheet.crop(width * 3, 0, width, height);
			orange = sheet.crop(0, height, width, height);
			btn_start[0] = red;
			btn_start[1] = blue;
			
			btn_end[0] = orange;
			btn_end[1] = cyan;
			
			all[0] = red;
			all[1] = cyan;
			
			player_up[0] = red;
			player_up[1] = red;
			
			player_left[0] = red;
			player_left[1] = red;

			
			player_right[0] = orange;
			player_right[1] = orange;

			
			player_down[0] = red;
			player_down[0] = red;

				
			
		}
}
