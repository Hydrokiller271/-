package com.sk.game;

import javax.swing.*;

public class Window extends JFrame {
    public Window() {

        setTitle("Soul Knight");
        // Hide or close the window with the help of setDefaultCloseOperation(int) method.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame or WindowConstants
        setContentPane(new GamePanel(1280, 720));
        setIgnoreRepaint(true);
        pack(); // Pack() method creates a moderate space rather without using setSize or setBounds method
        setLocationRelativeTo(null); // Setting null will put the GUI at the center of the screen
        setResizable(true);
        setVisible(true);
    }
}
