package com.sk.game.states;

import com.sk.game.GamePanel;
import com.sk.game.entities.Enemy;
import com.sk.game.entities.Player;
import com.sk.game.graphics.Sprite;
import com.sk.game.tiles.TileManager;
import com.sk.game.utils.*;

import java.awt.*;

public class PlayState extends GameState {

    private Font font;
    private Player player;
    private Enemy enemy;
    private TileManager tm;
    private Camera cam;

    public static Vector2f map;

    public PlayState(GameStateManager gsm) {
        super(gsm);

        map = new Vector2f();
        Vector2f.setWorldVar(map.x, map.y);

        cam = new Camera(new AABB(new Vector2f(0, 0), GamePanel.width + 64 , GamePanel.height + 64));
        tm = new TileManager("tile/tilemap.xml", cam);
        font = new Font("font/font.png", 10, 10);

        enemy = new Enemy(cam, new Sprite("entity/wizardPlayer.png", 64, 64),
                new Vector2f(0 + (GamePanel.width / 2) - 32 + 150, 0 + (GamePanel.height / 2) - 32 + 150), 64);
        player = new Player(new Sprite("entity/linkFormatted.png"),
                new Vector2f(0 + (GamePanel.width / 2) - 32, 0 + (GamePanel.height / 2) - 32), 64);

        cam.target(player);
    }

    public void update() {
        Vector2f.setWorldVar(map.x, map.y);
        player.update(enemy);
        enemy.update(player);
        cam.update();
    }

    public void input(MouseHandler mouse, KeyHandler key) {
        key.escape.tick();

        player.input(mouse, key);
        cam.input(mouse, key);

        if(key.escape.clicked) {
            if(gsm.getState(GameStateManager.PAUSE)) {
                gsm.pop(GameStateManager.PAUSE);
            } else {
                gsm.add(GameStateManager.PAUSE);
            }
        }
    }

    public void render(Graphics2D gp2d) {
        tm.render(gp2d);
        Sprite.drawArray(gp2d, font, GamePanel.oldFrameCount + " FPS", new Vector2f(GamePanel.width - 192, 32), 32, 32, 24, 0);
        player.render(gp2d);
        enemy.render(gp2d);
        cam.render(gp2d);
    }
}
