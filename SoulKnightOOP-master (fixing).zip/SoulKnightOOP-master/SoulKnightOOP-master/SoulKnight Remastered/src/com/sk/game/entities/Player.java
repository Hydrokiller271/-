package com.sk.game.entities;

import com.sk.game.GamePanel;
import com.sk.game.graphics.Sprite;
import com.sk.game.states.PlayState;
import com.sk.game.utils.KeyHandler;
import com.sk.game.utils.MouseHandler;
import com.sk.game.utils.Vector2f;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

import com.sk.game.utils.TileCollision;

public class Player extends Entity {

    public Player(Sprite sprite, Vector2f origin, int size) {
        super(sprite, origin, size);
        acc = 2f;
        maxSpeed = 4f;
        bounds.setWidth(25);
        bounds.setHeight(20);
        bounds.setXOffset(24);
        bounds.setYOffset(40);
    }

    private void move() {
        if (up) {
            dy -= acc;
            if (dy < -maxSpeed) {
                dy = -maxSpeed;
            }
        } else {
            if (dy < 0) {
                dy += deacc;
                if (dy > 0) {
                    dy = 0;
                }
            }
        }

        if (down) {
            dy += acc;
            if (dy > maxSpeed) {
                dy = maxSpeed;
            }
        } else {
            if (dy > 0) {
                dy -= deacc;
                if (dy < 0) {
                    dy = 0;
                }
            }
        }

        if (left) {
            dx -= acc;
            if (dx < -maxSpeed) {
                dx = -maxSpeed;
            }
        } else {
            if (dx < 0) {
                dx += deacc;
                if (dx > 0) {
                    dx = 0;
                }
            }
        }

        if (right) {
            dx += acc;
            if (dx > maxSpeed) {
                dx = maxSpeed;
            }
        } else {
            if (dx > 0) {
                dx -= deacc;
                if (dx < 0) {
                    dx = 0;
                }
            }
        }
    }

    private void resetPosition() {
        System.out.println("Resetting Player...");
        pos.x = GamePanel.width / 2 - 32;
        PlayState.map.x = 0;

        pos.y = GamePanel.height / 2 - 32;
        PlayState.map.y = 0;
    }

    public void update(Enemy enemy) {
        super.update();

        if(attack && hitBounds.collides(enemy.getBounds())) {
            System.out.println("I'm hitting!");
        }

        if(!fallen) {
            move();
            if (!tc.collisionTile(dx, 0)) {
                //PlayState.map.x += dx; -> Move player without moving camera - Episode 24
                pos.x += dx;
                xCol = false;
            } else {
                xCol = true;
            }
            if (!tc.collisionTile(0, dy)) {
                //PlayState.map.y += dy; -> Move player without moving camera - Episode 24
                pos.y += dy;
                yCol = false;
            } else {
                yCol = true;
            }
        } else {
            xCol = true;
            yCol = true;
            if (ani.hasPlayedOnce()) {
                resetPosition();
                dx = 0;
                dy = 0;
                fallen = false;
            }
        }
    }

    @Override
    public void render(Graphics2D gp2d) {
        gp2d.setColor(Color.green);
        gp2d.drawRect((int) (pos.getWorldVar().x + bounds.getXOffset()), (int) (pos.getWorldVar().y + bounds.getYOffset()),
                (int) bounds.getWidth(), (int) bounds.getHeight());

        if(attack) {
            gp2d.setColor(Color.yellow);
            gp2d.drawRect((int) (hitBounds.getPos().getWorldVar().x + hitBounds.getXOffset()),
                    (int) (hitBounds.getPos().getWorldVar().y + hitBounds.getYOffset()), (int) hitBounds.getWidth(), (int) hitBounds.getHeight());
        }
        gp2d.drawImage(ani.getImage(), (int) (pos.getWorldVar().x), (int) (pos.getWorldVar().y), size, size, null);

    }
    //Input
    public void input(MouseHandler mouse, KeyHandler key) {
    	MouseEvent e = null;
        if (mouse.getButton() == 1 ) {
            System.out.println("Player: " + pos.x + ", " + pos.y);
        }
        if (!fallen) {
            if (key.up.down) {
                up = true;
            } else {
                up = false;
            }
            if (key.down.down) {
                down = true;
            } else {
                down = false;
            }
            if (key.left.down) {
                left = true;
            } else {
                left = false;
            }
            if (key.right.down) {
                right = true;
            } else {
                right = false;
            }
            if (key.attack.down) {
                attack = true;
            } else {
                attack = false;
            }

        } else {
            up = false;
            down = false;
            left = false;
            right = false;
        }
    }
}

