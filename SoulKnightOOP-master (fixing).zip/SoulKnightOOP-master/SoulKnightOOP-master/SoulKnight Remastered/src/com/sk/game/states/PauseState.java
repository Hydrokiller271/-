package com.sk.game.states;

import com.sk.game.utils.KeyHandler;
import com.sk.game.utils.MouseHandler;

import java.awt.*;

public class PauseState extends GameState {
    public PauseState(GameStateManager gsm) {
        super(gsm);
    }

    @Override
    public void update() {
        System.out.println("PAUSED");
    }

    @Override
    public void input(MouseHandler mouse, KeyHandler key) {

    }

    @Override
    public void render(Graphics2D gp2d) {

    }
}
